from django.shortcuts import render, redirect
from .models import Task

def todo_list(request):
    tasks = Task.objects.all()
    return render(request, 'todo_app/todo_list.html', {'tasks': tasks})

def add_task(request):
    if request.method == 'POST':
        title = request.POST['title']
        Task.objects.create(title=title)
    return redirect('todo_list')

def remove_task(request, task_id):
    task = Task.objects.get(pk=task_id)
    task.delete()
    return redirect('todo_list')
