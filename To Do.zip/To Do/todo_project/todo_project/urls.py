from django.urls import path
from todo_app import views

urlpatterns = [
    path('', views.todo_list, name='todo_list'),
    path('add/', views.add_task, name='add_task'),
    path('remove/<int:task_id>/', views.remove_task, name='remove_task'),
]
